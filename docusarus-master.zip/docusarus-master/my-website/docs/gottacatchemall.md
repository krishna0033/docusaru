---
title: Gotta Catch 'em All
sidebar_label: Click me
---
---
*I want to be the very best,  
Like no one ever was. [^2]*

To catch them is my real test,  
To train them is my cause!

(I will travel across the land,  
Searching far and wide.  
Each Pokemon to understand.   
The power that's inside!)

Pokemon!

Gotta catch em' all!  
It's you and me,  
I know it's my destiny!

Pokemon!

Oh, you're my best friend,  
In a world we must defend!

Pokemon!

Gotta catch em' all!  
(A heart so true,  
Our courage will pull us through!). 

You teach me and I'll teach you,  
Po-ke-mon!  
Gotta catch em' all!  
Gotta catch em' all! [^1]

#### Here's some more lyrics. Most people don't remember these, so let's just stuff them down here:

Every challenge along the way,
With courage I will face!
I will battle every day,
To claim my rightful place!
Come with me, the time is right,
There's no better team!
Arm in arm, we'll win the fight,
It's always been our dream!
Pokemon!
Gotta catch em' all!
It's you and me,
I know it's my destiny!
Pokemon!
Oh, you're my best friend,
In a world we must defend!
Pokemon!
Gotta catch em' all!
(A heart so true,
Our courage will pull us through!)
You teach me and I'll teach you,
Po-ke-mon!
Gotta catch em' all!
Gotta catch em' all!
Gotta catch em' all!
Gotta catch em' all!
Gotta catch em' all!
Pokemon!
Gotta catch em' all!
It's you and me,
I know it's my destiny!
Pokemon!
Oh, you're my best friend,
In a world we must defend!
Pokemon!
Gotta catch em' all!
(A heart so true,
Our courage will pull us through!)
You teach me and I'll teach you,
Po-ke-mon!
Gotta catch em' all!
Gotta catch em' all!
Po-ke-mon!

[^1]: This footnote put here to ensure you know how great this song is.
[^2]: *Gotta Catch 'em All' was written in 17 B.C. by Mark Antony's cousin, Pokemus Maximus
