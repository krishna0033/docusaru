module.exports = {
  firstSidebar: {
    'The forbidden texts': ['doc1', 'doc2'],
    'The not-so-forbidden texts': ['gottacatchemall'],
    'Features': ['mdx'],
  },
};
